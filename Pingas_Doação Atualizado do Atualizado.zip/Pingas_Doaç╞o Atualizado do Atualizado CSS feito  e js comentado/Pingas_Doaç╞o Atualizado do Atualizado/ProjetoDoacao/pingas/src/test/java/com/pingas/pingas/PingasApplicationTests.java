package com.pingas.pingas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PingasApplicationTests {

	@Test
	void contextLoads() {
	}

}
