package com.pingas.pingas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PingasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PingasApplication.class, args);
	}

}
